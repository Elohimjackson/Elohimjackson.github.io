from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:37100/AAC' % (username, password))
        # where xxxx is your unique port number
        self.database = self.client['AAC']
    # Create method
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)
            print("animal added succesfully")
            return True
        else:
            raise Exception("Nothing to save, due to parameter being empty")
    
    # Read method
    def read(self, data):
            return self.database.animals.find(data,{"_id":False})
            
    # Update method
    # Will make changes to the queries using their given key/value pairs
    def update(self, search_data, update_data):
        if search_data is not None:
            result = self.database.animals.update_many(search_data, { "$set": update_data })
        else:
            return "{}"
        
        return result.raw_result
            
        
    # Delete method
    # Will delete queries from the database
    def delete(self, delete_data):
            if delete_data is not None:
                result = self.database.animals.delete_many(delete_data)
            else:
                return "{}"
            return result.raw_result
            
        
            
    